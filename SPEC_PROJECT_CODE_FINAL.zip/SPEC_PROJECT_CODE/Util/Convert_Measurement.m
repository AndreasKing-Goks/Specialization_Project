function Output = Convert_Measurement(Pos_N_M, Velo_B_M, Acc_B_M)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Convert_Measurement()                                                   %
%                                                                         %              
% Convert measurement data to force (NOT FINISHED)     %
%                                                                         %
% Created:      27.09.2023	Andreas Sitorus                               %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Pos_E = Pos_N_M;
Velo_B = Velo_B_M;
Acc_B = Acc_B_M;

end
function res = compute_centroid( dimension, arr )
    res = sum( arr )/dimension;
end